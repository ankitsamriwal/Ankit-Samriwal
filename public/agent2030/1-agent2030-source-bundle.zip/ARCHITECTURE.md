# Agent 2030 Learning Lab
October 8, 2026. Private synthetic prototype, not an autonomous personal agent yet.

## Architecture
Experience journal -> skill proposal -> explicit version review -> simulated reuse -> feedback revision. Confirmed synthetic preferences, goals and boundaries form an editable user model. A new session retains these records. The local server writes state atomically to data/state.json; a restart reloads it. Export returns a portable JSON snapshot.

Skills retain source experience IDs and version history. A rejected revision does not replace the active version. Memory corrections retain history; Forget removes the value and its history. The audit records only the forgotten key, not its value. Memory and skill approval never authorize external effects.

Node server, plain HTML/CSS/JavaScript, no production database dependency. Binding is loopback-only, host checked, writes require same-origin plus a per-process token. This is defense for a local demo, not deployable authentication. No external tool execution, credentials, user accounts, real data ingestion or network model calls.

## Model boundary
config.json selects google/gemma-4-26b-a4b-it:free. October 8 OpenRouter catalog verified the :free suffix, (free) display tag and zero prompt/completion price. Mode remains local-synthetic; no key or calls. Changing models means editing config, not an in-app selector. A later model adapter must recheck the live catalog before a request, validate structured output, keep free-only routing and fail closed. Do not treat free pricing as a privacy guarantee.

## What's testable
Load story; record experience; propose/approve/reject skill; simulate success/failure; propose and review a revision; confirm/edit/forget memories; start next session; reload/restart retention; export; reset with a typed confirmation. The 2030 page shows memory as a user-controlled asset and skills as compounding practice. It is a product direction, not a forecast.

## What is not implemented
Autonomous inference or skill discovery, vector retrieval, cross-device sync, encrypted storage, real personal integrations, action execution, live model calls, tunnel access or Vercel deployment. Supplied lesson lines become proposed skill steps deterministically. The app is not Hermes and makes no claim to reproduce its implementation.

## Run locally
Use Node 22 or later. `npm start`, then open http://127.0.0.1:8787 on that computer. Runtime has no npm dependencies. Windows launch: double-click start-windows.cmd after installing Node. A phone cannot access the loopback address; choose a protected sharing route before exposure.

## Verification
264/264 domain checks: 24 cases for each of 11 functions. 243/243 UI/integration checks: six complete flows repeated 20 times at 390x844 and 1365x900, plus export, unauthorized-write rejection and actual server restart retention. Tests use different loop inputs but are not 243 unrelated workflows. All flows have no horizontal overflow and no browser JS errors. Screenshots visually inspected for skills, memory and 2030 pages at both widths. Not tested on physical Galaxy S25 FE or Windows OS; Chromium viewport tests are not device certification.

Fixed and retested: missing/null model pricing initially passed Number(null)==0; now rejected. Memory category label was not matched reliably; explicit label added. Adjacent memory buttons had no spacing; fixed. Active versus rejected latest skill version made explicit.

## Sources
- https://hermes-agent.nousresearch.com/ : vendor description of persistent memory and skills from experience.
- https://hermes-agent.nousresearch.com/docs/user-guide/features/skills : on-demand skill documents, source-based learning and skill-management review boundaries.
- https://hermes-agent.nousresearch.com/docs/user-guide/features/memory : documented memory system. Inspiration, not copied code.
- https://openrouter.ai/docs/guides/routing/model-variants/free : free variant routing documentation.
- https://openrouter.ai/api/v1/models : live October 8 pricing/tag verification.
