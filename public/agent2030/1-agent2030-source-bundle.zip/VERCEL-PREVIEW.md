# Vercel preview
Approved route: existing site /agent2030. Ankit Samriwal, synthetic only.
This static version stores state in this browser's localStorage. No shared server memory or cross-device sync. Clearing site data removes it. Export is a JSON download. No model calls or external effects.
Tests: 242/242 static UI checks, including six flows repeated 20 times at 390px and desktop, export and persistence across browser reload/static-server restart. The local Node build has a separate server-backed store and test matrix; it is not the deployed persistence mode.
