import http from 'node:http';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {randomBytes} from 'node:crypto';import * as core from './core.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),config=JSON.parse(fs.readFileSync(path.join(root,'config.json'))),dir=process.env.DATA_DIR||path.join(root,'data');fs.mkdirSync(dir,{recursive:true});
const statePath=path.join(dir,'state.json');let state=fs.existsSync(statePath)?JSON.parse(fs.readFileSync(statePath)):core.empty();const token=randomBytes(24).toString('hex');
const save=()=>{const tmp=statePath+'.tmp';fs.writeFileSync(tmp,JSON.stringify(state,null,2),{mode:0o600});fs.renameSync(tmp,statePath)};
const json=(res,status,x)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(x))};
const port=Number(process.env.PORT||config.port),origin='http://127.0.0.1:'+port;
http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
 const allowed=['127.0.0.1:'+port,'localhost:'+port];if(!allowed.includes(req.headers.host)){json(res,403,{error:'Local host only.'});return}
 const u=new URL(req.url,origin);
 if(req.method==='GET'&&u.pathname==='/api/state'){json(res,200,{state,summary:core.summary(state),token,mode:config.mode,model:config.model});return}
 if(req.method==='GET'&&u.pathname==='/api/export'){res.setHeader('Content-Disposition','attachment; filename="agent2030-synthetic-state.json"');json(res,200,state);return}
 if(req.method==='POST'&&u.pathname.startsWith('/api/')){
  if(!['http://127.0.0.1:'+port,'http://localhost:'+port].includes(req.headers.origin)||req.headers['x-lab-token']!==token){json(res,403,{error:'Reload this local lab before making changes.'});return}
  let raw='';try{for await(const chunk of req){raw+=chunk;if(raw.length>12000)throw Error('Request too large.')}const b=JSON.parse(raw),next=structuredClone(state);let result;
   switch(u.pathname){case '/api/session':result=core.newSession(next);break;case '/api/experience':result=core.recordExperience(next,b);break;case '/api/propose':result=core.proposeSkill(next,b.id);break;case '/api/review':result=core.reviewSkill(next,b.id,b.decision);break;case '/api/reuse':result=core.reuseSkill(next,b.id,b.result);break;case '/api/revise':result=core.reviseSkill(next,b.id,b.lesson);break;case '/api/memory':result=core.remember(next,b);break;case '/api/forget':result=core.forget(next,b.id);break;case '/api/demo':result=core.demo(next);break;case '/api/reset':if(b.confirm!=='RESET SYNTHETIC LAB')throw Error('Type RESET SYNTHETIC LAB.');Object.assign(next,core.empty());result='reset';break;default:json(res,404,{error:'Unknown action.'});return}
   const old=state;state=next;try{save()}catch(e){state=old;throw e}json(res,200,{result,summary:core.summary(state)});
  }catch(e){json(res,400,{error:e.message})}return;
 }
 if(req.method!=='GET'){json(res,405,{error:'Method not allowed.'});return}
 const files={'/':'index.html','/app.mjs':'app.mjs','/style.css':'style.css'};const file=files[u.pathname];if(!file){json(res,404,{error:'Not found.'});return}
 res.setHeader('Content-Type',file.endsWith('.css')?'text/css':file.endsWith('.mjs')?'text/javascript':'text/html');res.end(fs.readFileSync(path.join(root,'public',file)));
}).listen(port,config.host,()=>console.log('Agent 2030 local synthetic lab: '+origin));
