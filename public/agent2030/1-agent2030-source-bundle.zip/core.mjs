import {randomUUID} from 'node:crypto';
export const empty=()=>({schema:1,session:0,experiences:[],skills:[],memories:[],events:[]});
const text=(v,max=1200)=>{if(typeof v!=='string'||!v.trim()||v.trim().length>max)throw Error('Enter text within the stated limit.');return v.trim()};
const id=()=>randomUUID();
const event=(s,type,detail)=>s.events.push({id:id(),type,detail,session:s.session,at:new Date().toISOString()});
const find=(list,key)=>{const x=list.find(x=>x.id===key);if(!x)throw Error('Item not found.');return x};
export function newSession(s){s.session++;event(s,'session','Started a new session; memory and skills retained.');return s.session}
export function recordExperience(s,input){
 const task=text(input.task,180),lesson=text(input.lesson),outcome=input.outcome;
 if(!['success','failure'].includes(outcome))throw Error('Choose success or failure.');
 if(input.synthetic!==true)throw Error('Synthetic examples only in this prototype.');
 if(s.experiences.length>=500)throw Error('Experience limit reached.');
 const x={id:id(),task,lesson,outcome,synthetic:true,session:s.session,at:new Date().toISOString()};s.experiences.push(x);event(s,'experience',task);return x;
}
export function proposeSkill(s,experienceId){
 const x=find(s.experiences,experienceId);
 const existing=s.skills.find(k=>k.sourceIds.includes(x.id));if(existing)return existing;
 const steps=x.lesson.split(/\n+/).map(v=>v.trim()).filter(Boolean);
 const k={id:id(),name:x.task,status:'proposed',sourceIds:[x.id],versions:[{number:1,steps,reason:'Derived from recorded synthetic experience.',status:'pending'}],activeVersion:null,uses:0,successes:0,failures:0};
 s.skills.push(k);event(s,'skill-proposed',k.name);return k;
}
export function reviewSkill(s,skillId,decision){
 const k=find(s.skills,skillId),v=k.versions.at(-1);
 if(!['approve','reject'].includes(decision))throw Error('Choose approve or reject.');
 if(v.status!=='pending')throw Error('This version has already been reviewed.');
 v.status=decision==='approve'?'approved':'rejected';
 if(decision==='approve'){k.activeVersion=v.number;k.status='active'}else{k.status=k.activeVersion?'active':'rejected'};
 event(s,'skill-reviewed',k.name+' v'+v.number+' '+v.status);return k;
}
export function reuseSkill(s,skillId,result){
 const k=find(s.skills,skillId);if(!k.activeVersion)throw Error('Approve a version before reuse.');
 if(!['success','failure'].includes(result))throw Error('Choose success or failure.');
 k.uses++;if(result==='success')k.successes++;else k.failures++;
 event(s,'skill-reused',k.name+' v'+k.activeVersion+' '+result);return k;
}
export function reviseSkill(s,skillId,lesson){
 const k=find(s.skills,skillId);if(!k.activeVersion)throw Error('Approve a version before revising.');
 if(k.versions.at(-1).status==='pending')throw Error('Review the pending revision first.');
 const steps=text(lesson).split(/\n+/).map(v=>v.trim()).filter(Boolean);
 k.versions.push({number:k.versions.length+1,steps,reason:'Correction from synthetic feedback.',status:'pending'});k.status='revision-pending';event(s,'revision-proposed',k.name);return k;
}
export function remember(s,input){
 const key=text(input.key,80).toLowerCase(),value=text(input.value,400);
 if(!['preference','goal','boundary'].includes(input.kind))throw Error('Choose a memory category.');
 if(input.confirmed!==true||input.synthetic!==true)throw Error('Confirm this synthetic memory explicitly.');
 const old=s.memories.find(m=>m.key===key);
 if(old){old.history.push({value:old.value,kind:old.kind,session:old.session});old.value=value;old.kind=input.kind;old.session=s.session;event(s,'memory-corrected',key);return old}
 if(s.memories.length>=200)throw Error('Memory limit reached.');
 const m={id:id(),key,value,kind:input.kind,session:s.session,history:[],synthetic:true};s.memories.push(m);event(s,'memory-confirmed',key);return m;
}
export function forget(s,memoryId){const m=find(s.memories,memoryId);s.memories=s.memories.filter(x=>x.id!==memoryId);event(s,'memory-forgotten',m.key);return m.key}
export function summary(s){return {sessions:s.session,experiences:s.experiences.length,activeSkills:s.skills.filter(k=>k.activeVersion).length,pending:s.skills.filter(k=>k.versions.at(-1).status==='pending').length,memories:s.memories.length,reuses:s.skills.reduce((n,k)=>n+k.uses,0)}}
export function selectFreeModel(catalog,model){
 if(!Array.isArray(catalog?.data))throw Error('Cannot verify model catalog.');
 const x=catalog.data.find(x=>x.id===model);
 if(!x||!x.id.endsWith(':free')||!x.name.toLowerCase().includes('(free)')||!['prompt','completion'].every(k=>x.pricing?.[k]!==null && x.pricing?.[k]!==undefined && x.pricing?.[k]!=='' && Number(x.pricing[k])===0))throw Error('Model is not verified free.');
 return x.id;
}
export function demo(s){
 if(s.experiences.length||s.skills.length||s.memories.length)throw Error('Demo loads only into an empty lab.');
 newSession(s);
 const x=recordExperience(s,{task:'Prepare a weekend itinerary',lesson:'Check opening hours before adding a venue.\nKeep transit and meal breaks visible.\nAsk before any paid reservation.',outcome:'success',synthetic:true});
 remember(s,{key:'planning style',value:'Leave breathing room between activities.',kind:'preference',confirmed:true,synthetic:true});
 remember(s,{key:'spending boundary',value:'Ask before spending or making a booking.',kind:'boundary',confirmed:true,synthetic:true});
 proposeSkill(s,x.id);return summary(s);
}
